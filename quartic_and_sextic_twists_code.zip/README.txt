This zip folder includes SageMath programs to generate the data appearing in Figures 1 and 2 in the paper

M. Weidner, On Conjectural Rank Parities of Quartic and Sextic Twists of Elliptic Curves, Int. J. Number Theory 15(9) (2019) 1895-1918, https://doi.org/10.1142/S1793042119501057.

See the headers in each file for a description of what they generate.  classify_Q1728.sage corresponds to Figure 1 while classify_Q0.sage corresponds to Figure 2.

Note that these programs actually generate outdated versions of the tables in the paper (in LaTeX), which redundantly include all combinations of input values, instead of separating out the contributions of each prime into separate tables as is done in published paper.
